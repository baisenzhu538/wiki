# 关键数据库索引

在 Step 3 在线信息采集时，优先指定以下数据库。

## 企业信息

| 平台 | 用途 |
|------|------|
| 天眼查 tianyancha.com | 企业全景：工商、股东、投资、诉讼、知识产权 |
| 企查查 qcc.com | 企业征信、尽调报告、关联企业 |
| 国家企业信用信息公示系统 gsxt.gov.cn | 官方工商数据源 |
| 信用中国 creditchina.gov.cn | 信用信息、失信记录 |
| 中国裁判文书网 wenshu.court.gov.cn | 涉诉信息、法律纠纷 |

## 投融资

| 平台 | 用途 |
|------|------|
| IT桔子 itjuzi.com | TMT 创投数据库 |
| 36氪创投 pitchhub.36kr.com | 融资事件、项目信息 |

## 流量与运营

| 平台 | 用途 |
|------|------|
| SimilarWeb similarweb.com | 网站流量估算、来源分析 |
| 七麦数据 qimai.cn | 国内 App 市场数据 |
| Sensor Tower sensortower.com | 全球移动应用数据 |

## 趋势与指数

| 平台 | 用途 |
|------|------|
| 百度指数 index.baidu.com | 国内搜索热度 |
| Google Trends trends.google.com | 全球搜索趋势 |
| 巨量算数 trendinsight.oceanengine.com | 抖音生态趋势 |

## 口碑与投诉

| 平台 | 用途 |
|------|------|
| 黑猫投诉 tousu.sina.cn | 消费者投诉记录 |
| 12315平台 12315.cn | 官方投诉举报 |

## 行业报告

| 平台 | 用途 |
|------|------|
| 艾瑞咨询 iresearch.com.cn | 互联网与新经济报告 |
| 易观分析 analysys.cn | 数字经济行业分析 |
| 发现报告 fxbaogao.com | 券商研报聚合 |
| Statista statista.com | 全球统计数据 |

## 短视频与电商

| 平台 | 用途 |
|------|------|
| 蝉妈妈 chanmama.com | 抖音直播/电商数据 |
| 新榜 newrank.cn | 多平台新媒体数据 |
| 飞瓜数据 feigua.cn | 短视频/直播数据 |
| 千瓜数据 qian-gua.com | 小红书数据 |

## 财报与公告

| 平台 | 适用市场 |
|------|---------|
| 巨潮资讯网 cninfo.com.cn | A 股 |
| 港交所披露易 hkexnews.hk | 港股 |
| SEC EDGAR sec.gov/edgar | 美股 |

## 专利检索

| 平台 | 用途 |
|------|------|
| 国家知识产权局 pss-system.cponline.cnipa.gov.cn | 中国专利 |
| 佰腾网 baiten.cn | 全球专利 AI 搜索 |
| Google Patents patents.google.com | 全球专利快速检索 |

## 招聘信息

| 平台 | 用途 |
|------|------|
| Boss直聘 zhipin.com | 招聘动态、团队规模 |
| 拉勾 lagou.com | 互联网行业招聘 |
| 猎聘 liepin.com | 中高端招聘 |

## 全球创投与企业数据库（国际化调研必查）

| 平台 | 用途 | 特点 |
|------|------|------|
| Crunchbase crunchbase.com | 全球创投数据库 | 融资、投资人、行业图谱 |
| PitchBook pitchbook.com | 经验证的财务数据 | 资本表、估值（付费） |
| CB Insights cbinsights.com | 预测性市场情报 | 市场地图、趋势识别（付费） |
| Dealroom dealroom.co | 欧洲生态系统 | 100+ 政府数据源合作 |
| Tracxn tracxn.com | 新兴市场数据 | ML + 分析师双轮审核 |
| AlphaSense alpha-sense.com | 金融研究 + 专家访谈记录 | 合并 CI + 专家 + 财报 |
| Product Hunt producthunt.com | 新产品发现 | 发布时间线、用户初评 |

## 另类数据（Alternative Data）

另类数据是传统财务数据之外的非传统数据源。2025 年全球另类数据市场达 140-180 亿美元，70%+ 对冲基金已在使用。

| 类型 | 代表平台/方法 | 用途 | 适用场景 |
|------|-------------|------|---------|
| **卫星图像** | Planet Labs, RS Metrics | 停车场车辆计数 → 推算零售营收 | 实体零售、仓储物流 |
| **消费交易数据** | Earnest Research, Second Measure | 信用卡交易聚合 → 推算私企真实营收 | 未上市公司营收验证 |
| **App 使用数据** | Sensor Tower, data.ai | 应用内使用时长、留存、收入估算 | 移动互联网公司验证 |
| **SEO/广告数据** | Semrush, SpyFu, BuiltWith | 竞品 SEO 排名、付费广告投入、技术栈 | 线上获客策略分析 |
| **电商数据** | 魔镜洞察 mktindex.com, 生意参谋 | 在线零售市场 AI 分析 | 电商竞品分析 |
| **专家访谈记录库** | Tegus, AlphaSense, Third Bridge Forum | 搜索数千条已有专家访谈记录 | 先查记录再约专家（节省 70% 费用）|

> 最佳实践：在花 $500-1500/小时约专家之前，先搜索 Tegus/AlphaSense 等平台的历史访谈记录，70-80% 的问题可能已有现成答案。
